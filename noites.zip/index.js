import express from "express";
import path from "path";
import fs from "fs";

const app = express();
const PORT = 3000;
const __dirname = path.resolve();

// Carregar senhas únicas de um arquivo JSON
const passwordsFile = path.join(__dirname, "passwords.json");
let passwords = JSON.parse(fs.readFileSync(passwordsFile, "utf8"));

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

// Rota para a página inicial
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Rota de login
app.post("/login", (req, res) => {
    const { password } = req.body;
    
    if (passwords.includes(password)) {
        // Remove a senha usada
        passwords = passwords.filter(p => p !== password);
        fs.writeFileSync(passwordsFile, JSON.stringify(passwords, null, 2));
        res.redirect("/intro");
    } else {
        res.send("<script>alert('Senha inválida ou já utilizada!'); window.location.href='/';</script>");
    }
});

// Rota para o vídeo introdutório
app.get("/intro", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "intro.html"));
});

// Rota para a caixa de entrada fake
app.get("/emails", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "emails.html"));
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
