const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Rota explícita para video-final.html
app.get('/video-final.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'video-final.html'));
});

// Rota para servir o vídeo final
app.get('/video/video-final.mp4', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'video', 'video-final.mp4'));
});

// Carregar senhas válidas de um arquivo
const senhasArquivo = 'senhas.json';
let senhasValidas = [];

if (fs.existsSync(senhasArquivo)) {
    senhasValidas = JSON.parse(fs.readFileSync(senhasArquivo, 'utf8'));
} else {
    senhasValidas = ["senha123", "culto2025", "ocultismo", "acertoem3d"];
    fs.writeFileSync(senhasArquivo, JSON.stringify(senhasValidas, null, 2));
}

// Rota de login
app.post('/login', (req, res) => {
    const { nomeJogador, nomeEquipe, senha } = req.body;

    if (senha === "acertoem3d" || senhasValidas.includes(senha)) {
        if (senha !== "acertoem3d") {
            senhasValidas = senhasValidas.filter(s => s !== senha);
            fs.writeFileSync(senhasArquivo, JSON.stringify(senhasValidas, null, 2));
        }

        let ranking = [];
        if (fs.existsSync('ranking.json')) {
            try {
                ranking = JSON.parse(fs.readFileSync('ranking.json', 'utf8'));
            } catch (error) {
                console.error("❌ Erro ao ler ranking.json:", error);
                ranking = [];
            }
        }

        let equipeIndex = ranking.findIndex(e => e.equipe === nomeEquipe);
        if (equipeIndex !== -1) {
            if (!ranking[equipeIndex].jogadores.includes(nomeJogador)) {
                ranking[equipeIndex].jogadores.push(nomeJogador);
            }
        } else {
            ranking.push({ equipe: nomeEquipe, jogadores: [nomeJogador], tempo: "Ainda não finalizado" });
        }

        fs.writeFileSync('ranking.json', JSON.stringify(ranking, null, 2));

        res.send(`
            <script>
                localStorage.setItem('nomeJogador', '${nomeJogador}');
                localStorage.setItem('nomeEquipe', '${nomeEquipe}');
                window.location.href = "/intro.html";
            </script>
        `);
    } else {
        res.send("Senha inválida. Tente novamente.");
    }
});

// Rota para carregar o ranking
app.get('/ranking', (req, res) => {
    try {
        if (!fs.existsSync('ranking.json')) {
            return res.json([]);
        }

        let rankingData = fs.readFileSync('ranking.json', 'utf8');
        let ranking = JSON.parse(rankingData);

        ranking = ranking.map(equipe => ({
            equipe: equipe.equipe || "Equipe Desconhecida",
            jogadores: equipe.jogadores || [],
            tempo: equipe.tempo && equipe.tempo !== "null" && equipe.tempo !== "Ainda não finalizado" 
                ? equipe.tempo 
                : "Ainda não finalizado"
        }));

        res.json(ranking);
    } catch (error) {
        console.error("❌ Erro ao carregar o ranking:", error);
        res.status(500).json({ error: "Erro ao carregar ranking." });
    }
});

// Rota para salvar tempo no ranking (corrigido)
app.post('/salvar-ranking', (req, res) => {
    const { nomeEquipe, tempo } = req.body;

    console.log(`📌 Recebendo tempo para salvar: Equipe: ${nomeEquipe}, Tempo: ${tempo}`);

    if (!nomeEquipe || typeof tempo !== "string" || tempo.trim() === "" || tempo === "Ainda não finalizado") {
        console.log("❌ Erro: Nome da equipe ou tempo inválido!", req.body);
        return res.status(400).json({ error: 'Dados inválidos! Equipe e tempo são obrigatórios.' });
    }

    let ranking = [];
    if (fs.existsSync('ranking.json')) {
        try {
            ranking = JSON.parse(fs.readFileSync('ranking.json', 'utf8'));
        } catch (error) {
            console.error("❌ Erro ao ler ranking.json:", error);
            ranking = [];
        }
    }

    let equipeIndex = ranking.findIndex(e => e.equipe === nomeEquipe);
    
    if (equipeIndex !== -1) {
        console.log(`📌 Atualizando tempo da equipe: ${nomeEquipe}`);
        ranking[equipeIndex].tempo = String(tempo);
    } else {
        console.log(`📌 Criando nova equipe com tempo: ${nomeEquipe}`);
        ranking.push({ equipe: nomeEquipe, jogadores: [], tempo: String(tempo) });
    }

    ranking.sort((a, b) => {
        const tempoA = a.tempo !== "Ainda não finalizado" ? converterParaSegundos(a.tempo) : Infinity;
        const tempoB = b.tempo !== "Ainda não finalizado" ? converterParaSegundos(b.tempo) : Infinity;
        return tempoA - tempoB;
    });

    fs.writeFileSync('ranking.json', JSON.stringify(ranking, null, 2));
    res.json({ message: 'Ranking atualizado!', ranking });
});

// Função para converter "HH:MM:SS" em segundos
function converterParaSegundos(tempo) {
    if (!tempo || typeof tempo !== "string" || !tempo.includes(":")) return Infinity;
    const [horas, minutos, segundos] = tempo.split(":").map(Number);
    return (horas * 3600) + (minutos * 60) + segundos;
}

// Inicia o servidor
app.listen(PORT,() => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});

